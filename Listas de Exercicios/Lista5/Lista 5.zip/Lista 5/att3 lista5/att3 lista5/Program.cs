﻿using System.Diagnostics;

namespace att3_lista5
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Digite alguma coisa ou aperte enter e nos verificaremos se a lista esta vazia ou não");
             string texto = Console.ReadLine();
            bool cond = string.IsNullOrEmpty(texto);
            if (cond == true)
            {
                Console.WriteLine("Sua lista está vazia");
            }
            else
            {
                Console.WriteLine("Sua lista não está vazia");
            }
        }
        }
    }

