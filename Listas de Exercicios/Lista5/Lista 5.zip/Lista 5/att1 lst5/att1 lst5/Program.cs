﻿using System;
namespace att1_lst5
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Digite um numero e informarei se ele a par ou impar");
            double num = double.Parse(Console.ReadLine());
            bool cond = num % 2 == 0;
            if (cond == true)
            {
                Console.WriteLine("Seu numero e par ");
            }
            else
            {
                Console.WriteLine("Seu numero e impar");
            }
           
       }  
    }
}
