﻿namespace att7_lista5
{
    internal class Program
    {
        static void Main(string[] args)
        { 
                int loop = 0;
                Console.WriteLine("Digite um numero e falarei se e positivo negativo ou zero ");
                int num = int.Parse(Console.ReadLine());
            bool? cond;
             cond = num == 0 ? true : num > 0 ? false:null;
            if (cond == true)
            {

                Console.WriteLine("Seu numero e zero");
            }
            else if (cond == false)
            {
                Console.WriteLine("Seu numero e maior que 0");
            }
            else {
                Console.WriteLine("Seu numero e menor que 0");
            }

            }
        }
    }


