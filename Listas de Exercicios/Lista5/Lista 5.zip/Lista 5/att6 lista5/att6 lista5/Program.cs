﻿namespace att6_lista5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int loop = 0;
            Console.WriteLine("Digite um numero inteiro e lhe mostrarei seu valor absoluto ");
            int num = int.Parse(Console.ReadLine());
            bool cond = num == 0;
            while (cond == false)
            {
                if (num < 0)
                {
                    num++;
                    loop++;
                }
                else
                {
                    num = num - 1;
                    loop++;
                }
                cond = num == 0;
            }
            Console.WriteLine("Seu valor absoluto é " + loop);


        }
    }
}