﻿namespace att9_lista5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Digite dois numeros e verificaremos se um e divisivel pelo outro");
           double num1 = double.Parse(Console.ReadLine());
            double num2 = double.Parse(Console.ReadLine());
            bool cond = num1 % num2 == 0;

            if (cond) {
                Console.WriteLine("Seus numeros são divisiveis");

            }
            else
            {
                Console.WriteLine("Seus numeros não são divisiveis");
            }
        }
    }
}
