﻿using static System.Net.Mime.MediaTypeNames;

namespace att4_lista5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Escreva alguma coisa ou aperte enter ");
            string texto = Console.ReadLine ();
            bool cond = string.IsNullOrEmpty(texto);
            if (cond == true)
            {
                Console.WriteLine("Sua string esta vazia");
            }
            else
            {
                Console.WriteLine("Sua string não esta vazia ");
            }
        }
    }
}
