﻿namespace att2_lista5
{
    internal class att2_lista5
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Digite dois numero e informarei qual deles e o maior ");
            double num = double.Parse(Console.ReadLine());
            double num2 = double.Parse(Console.ReadLine());
            bool maior = num > num2;
            if (maior == true) {
                Console.WriteLine("O maior numero é o "+num);
            
            }
            else
            {
                Console.WriteLine("O maior numero é o "+num2);
            }



        }
    }
}
