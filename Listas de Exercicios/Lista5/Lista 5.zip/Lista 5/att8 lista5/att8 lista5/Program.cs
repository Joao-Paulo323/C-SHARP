﻿namespace att8_lista5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Digite um numero e eu converterei ele de string para double");
            string num = Console.ReadLine();
            string somenteNumeros = "";
            foreach (char c in num)
            {
                bool cond = char.IsDigit(c);
                if (cond)
                {
                    somenteNumeros += c;
                }
            }
            double num1 = double.Parse(somenteNumeros);
           
            Console.WriteLine("Os seus numeros são "+somenteNumeros);

        }
    }
}
