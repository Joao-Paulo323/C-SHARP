﻿namespace att5_lista5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Digite um numero entre 0 e 10");
            double num =double.Parse(Console.ReadLine());
            bool cond  = num > 0 && num < 10;
            if (cond == true)
            {
                Console.WriteLine("Sua condição esta certa");
            }
            else
            {
                Console.WriteLine("Sua condição esta errada");
            }

        }
    }
}
