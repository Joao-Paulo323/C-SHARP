﻿namespace att10_lista5
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Digite um numero e verificarei se ele e nulo ou não");
            string entrada = Console.ReadLine();
            double? num = string.IsNullOrEmpty(entrada)? null:double.Parse(entrada);
            bool cond = num == null;

            if (cond)
            {
                Console.WriteLine("Seu numero e nulo");
            }
            else
            {

                Console.WriteLine("Seu numero não e nulo");
            }

        }
    }
}
